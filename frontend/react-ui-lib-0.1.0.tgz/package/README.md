# ReactUILib

Biblioteca de componentes React con TypeScript, Radix Primitives, Tailwind CSS 4 y Motion. Los primitives resuelven interacción, foco y semántica; la librería conserva sus materiales, reflejos, colores y animaciones.

## Desarrollo y verificación

Requiere Node.js 22.12 o posterior; CI utiliza Node.js 24. React 18.2 y React 19 son peers compatibles.

```sh
npm install
npm run dev                # Playground en http://127.0.0.1:5173
npm run check              # Lint, tests, ambos builds y consumidor del paquete
npm run format             # Formato general y etiquetas JSX por renglón
npm run test:watch
npm run build              # JavaScript por módulos, CSS y declaraciones
npm run build:playground
npm run preview            # Requiere el build del playground
npm pack                   # Ejecuta el build antes de crear el paquete
```

`test:package` extrae el tarball en una aplicación temporal, enlaza las dependencias instaladas y verifica exports, CSS, declaraciones, render en servidor y eliminación de componentes no utilizados. No publica ni descarga el paquete. La matriz de CI ejecuta las comprobaciones con React 18 y 19.

## Playground

El playground usa el diseño del CRM, con una sidebar que agrupa Dashboard, Navegación, Botones, Formularios, Modales, Feedback, Presentación y Layout. La Dashboard inicia vacía en una grilla de 6 × 4 celdas cuadradas. «Agregar widget» abre un dropdown scrolleable con seis bloques de ejemplo; se pueden arrastrar a una celda o agregar con clic. El título permite moverlos y la esquina inferior derecha permite cambiar su tamaño. El layout se conserva al cambiar de sección.

La búsqueda encuentra grupos por nombre de componente (también con `⌘K` / `Ctrl K`). El encabezado permite cambiar el tema y reducir el movimiento. En pantallas pequeñas la sidebar se compacta automáticamente y los ejemplos se reorganizan según el espacio disponible.

`playground/PlaygroundShell.tsx` define la estructura y la navegación; `playground/Playground.tsx` conserva el estado de los ejemplos y registra los grupos. Cada demo vive en `playground/demos/`, y las descripciones y palabras de búsqueda están en `playground/sectionMetadata.ts`. Los estilos del playground viven en `playground/styles.css`, separados del CSS que se distribuye con la librería.

El [mapa del código](docs/mapa-del-codigo.md) indica dónde cambiar cada parte. `npm run format` aplica primero Prettier a TypeScript, JavaScript, HTML y CSS, y después ESLint separa las etiquetas, atributos y expresiones JSX. `npm run lint` verifica esas reglas; los bloques condicionales y bucles usan llaves explícitas.

## Uso

```tsx
import { Button, ToastProvider, UIProvider, useToast } from 'react-ui-lib';
import 'react-ui-lib/styles.css';

function SaveButton() {
  const { loading, updateToast } = useToast();
  async function save() {
    const id = loading('Guardando…');
    try {
      await savePreferences(); // Servicio de tu aplicación.
      updateToast(id, { type: 'success', title: 'Preferencias guardadas' });
    } catch {
      updateToast(id, { type: 'error', title: 'No se pudo guardar' });
    }
  }
  return <Button onClick={save}>Guardar</Button>;
}

export function App() {
  return (
    <UIProvider theme="system" accentColor="#3478ed" reducedMotion="system">
      <ToastProvider position="bottom-right" maxVisibleToasts={3}>
        <SaveButton />
      </ToastProvider>
    </UIProvider>
  );
}
```

La aplicación conserva el estado de negocio, valida datos, administra navegación y llama a sus servicios. Los componentes reciben valores y notifican cambios mediante callbacks. Los portales mantienen tema, acento y preferencias de movimiento. Montá un ToastProvider dentro de UIProvider.

El consumidor importa el CSS compilado; no necesita Tailwind. Para crear nuevas utilidades con `className`, sí debe configurar Tailwind en su aplicación. El reset de la librería se limita a `ui-root`: box sizing y tipografía de controles. No instala el reset global del playground.

El paquete es ESM. React, Radix, Motion y las utilidades permanecen como dependencias externas; el bundler consumidor puede compartirlas y eliminar módulos no usados. Sus tamaños siguen formando parte del coste real de la aplicación. Los módulos publicados incluyen `"use client"` para integraciones con React Server Components; eso no sustituye las pruebas de hidratación de cada aplicación.

## Tipografía

La biblioteca y el playground usan Sansation, también en el botón “Opciones”, con pesos 300, 400 y 700 y variantes normales y cursivas. La carga de Google Fonts, los tokens y la aplicación de la fuente al tema y los controles están centralizados en [`src/typography.css`](src/typography.css), importado por los estilos compartidos y incluido en el CSS del paquete.

Para probar otra familia, cambiá la URL de `@import` y `--font-sans` en ese archivo. Los pesos también se ajustan allí: `--font-weight-normal` para texto y botones, `--font-weight-medium` para etiquetas, `--font-weight-semibold` para subtítulos y `--font-weight-heading` para títulos principales. Las clases de Tailwind como `font-medium` y `font-semibold` usan los mismos tokens. `italic` o `<em>` utilizan la variante cursiva cargada.

Una aplicación consumidora puede cargar su propia fuente y sobrescribir los tokens después de importar `react-ui-lib/styles.css`:

```css
:root {
  --font-sans: 'Otra fuente', system-ui, sans-serif;
  --font-weight-heading: 600;
}
```

## API disponible

Todos estos componentes y sus tipos se exportan desde `react-ui-lib`:

| Área | Componentes | Base de comportamiento |
| --- | --- | --- |
| Acciones | Button, DropdownButton, SplitButton | Botón nativo; Radix Dropdown Menu |
| Formularios | TextField, Switch, RadioButton, RadioGroup | Input nativo; Radix Label, Switch y Radio Group |
| Navegación | Tabs, Sidebar | Radix Tabs; nav, enlaces y botones nativos |
| Capas flotantes | Dialog, Modal, Tooltip | Radix Dialog y Tooltip |
| Feedback | Toast, Spinner, Avatar | Radix Toast y Avatar; indicador nativo |
| Layout | Surface, Stack | HTML semántico y Motion |
| Dashboard | WidgetDashboard | CSS Grid, drag & drop nativo, Pointer Events y Radix Dropdown Menu |
| Agenda | CalendarWidget | Vista semanal adaptable, Modal y eventos por horario |
| Configuración | UIProvider, ToastProvider, useToast | Context de React y Radix Toast Provider |

`Size`, `UIProps`, `FieldProps`, `TabItem`, `RadioOption`, `SidebarItem`, `ToastType`, `ToastOptions` y `ToastContextValue` también son públicos. Las declaraciones TypeScript generadas son el contrato completo.

### Dashboard de widgets

La [guía de dashboard y widgets](docs/dashboard-widgets.md) explica el catálogo, el layout, las interacciones y la conexión con componentes y datos del CRM.

`WidgetDashboard` recibe `widgets` (catálogo), `layout` y `onLayoutChange`, además de `columns` y `rows` para definir la grilla n × m. Cada `DashboardWidgetDefinition` tiene `id`, `title`, `description`, un tamaño inicial `width` / `height` y `content` React. Cada `DashboardPlacement` identifica una instancia con `id` y `widgetId`, posición `column` / `row` desde cero y dimensiones enteras `width` / `height` en celdas. Una misma definición puede agregarse varias veces.

```tsx
const [layout, setLayout] = useState<DashboardPlacement[]>([]);

<WidgetDashboard
  columns={6}
  rows={4}
  widgets={[{ id: 'sales', title: 'Ventas', width: 2, height: 1, content: <SalesWidget /> }]}
  layout={layout}
  onLayoutChange={setLayout}
/>
```

El catálogo usa el morph compartido y un portal sin bloquear la dashboard. Su scroll oculta la barra y muestra el gradiente inferior mientras queda contenido. El arrastre desde el catálogo utiliza drag & drop nativo; mover y redimensionar usa Pointer Events, también con touch. Con teclado, Enter agrega y las flechas sobre los controles del título y de la esquina mueven o redimensionan. Escape cancela una operación. Todos los rectángulos de celdas son válidos mientras entren en la grilla y no se superpongan: no hay una lista de tamaños predefinidos. La aplicación conserva el layout y controla el contenido y la persistencia de negocio; si cambia `columns` / `rows`, debe entregar posiciones válidas para esas dimensiones.

Al agregar con clic o teclado, una superficie morph viaja desde la opción del catálogo hasta la celda y revela la tarjeta real al terminar. Las tarjetas y la vista previa animan sus cambios de posición y tamaño con la misma transición global, definida en `src/utils/motion.ts` mediante `morphTransition` y `morphTimeScale`. El contenido conserva sus proporciones durante el resize. El movimiento reducido aplica el estado final inmediatamente.

`CalendarWidget` puede usarse como `content` de una definición. Muestra la semana actual y abre una agenda semanal por horarios en un modal que se expande desde el widget. Permite recorrer semanas, agregar eventos al pulsar un cuadro y editar o eliminar eventos existentes desde un segundo modal. Los widgets y su dashboard viven en `src/widgets/`. Acepta `events` / `onEventsChange` para estado controlado o `defaultEvents` para estado local. El tipo público `CalendarEvent` incluye `id`, `date` local (`YYYY-MM-DD`), `title`, `time` opcional (`HH:mm`) y `durationMinutes` opcional (60 minutos por defecto), además de descripción y preferencias de notificación opcionales. La grilla usa franjas de tres horas y cada evento ocupa un espacio proporcional a su duración. La [guía del calendario](docs/dashboard-widgets.md#calendario) describe los tamaños adaptables, el teclado y la persistencia.

### Formularios

TextField usa `value` y `onChange(value)`, etiqueta visible, `helpText`, `error`, atributos nativos y ref al input. La variante predeterminada es `outlined`; `variant="filled"` muestra la etiqueta sobre un campo con fondo suave y admite acciones mediante `trailingIcon`. Admite los tipos de texto y también `date`, `time` y `number`, conservando los controles nativos del navegador y atributos como `min`, `max` y `step`. Switch usa `checked` y `onCheckedChange(checked)`, nombre, valor, required y atributos de botón. RadioGroup usa `options`, `value` y `onValueChange(value)`; las opciones deben tener valores únicos.

```tsx
<RadioGroup
  label="Frecuencia"
  name="frequency"
  value={frequency}
  onValueChange={setFrequency}
  options={[
    { value: 'daily', label: 'Diario' },
    { value: 'weekly', label: 'Semanal' },
    { value: 'live', label: 'En tiempo real', disabled: true },
  ]}
/>
```

Radix crea los inputs auxiliares para envío y validación HTML. RadioGroup ofrece navegación por flechas según `orientation="horizontal" | "vertical"`, salta opciones deshabilitadas y conserva una única selección. Usá RadioGroup para agrupar opciones: RadioButton aislado representa un control individual y no establece navegación por flechas entre instancias separadas.

Switch y RadioButton ahora exponen refs a **HTMLButtonElement**, siguiendo Radix. Sus props de eventos corresponden al botón visible. RadioGroup mantiene su ref a HTMLFieldSetElement.

### Menús y SplitButton

Button anima el cambio de tamaño al entrar y salir de `loading`; el spinner aparece y desaparece con un fundido y un pequeño desplazamiento. El texto y los iconos mantienen sus proporciones durante el resize. El estado de carga bloquea la interacción y expone `aria-busy`; con movimiento reducido, el cambio es inmediato.

DropdownButton mantiene `triggerLabel`, `buttons`, `triggerProps`, variantes y clases. `isOpen` y `onOpenChange` permiten control externo. `closeOnSelect={false}` conserva el menú después de ejecutar una acción. `position` admite `left`, `right`, `bottom_left` y `bottom_right`; Radix ajusta la colocación cuando no entra en el viewport. `avoidCollisions={false}` conserva la posición solicitada sin cambiar de lado. El menú usa un portal y conserva el tema. Escape cierra y devuelve el foco; flechas recorren opciones, y Enter/Espacio las activan.

```tsx
<SplitButton
  primaryIcon={<EditIcon />}
  primaryAriaLabel="Editar"
  onPrimaryClick={edit}
  dropdownLabel="Más acciones de edición"
  dropdownOptions={[{ key: 'copy', children: 'Copiar', onClick: copy }]}
/>
```

Si omitís `primaryLabel`, `primaryAriaLabel` es obligatorio. La flecha recibe `dropdownLabel`, cuyo valor predeterminado es "Más opciones". La prop `disabled` bloquea ambas acciones aunque `dropdownProps` intente habilitar el menú.

### Tabs

Usa `tabs: TabItem[]`, con `{ value, label, content, disabled? }`. Admite `value`/`onValueChange` o `defaultValue`; un valor controlado solo cambia cuando lo actualiza el padre. Cada instancia tiene su propio grupo de animación.

Opciones: `orientation`, `activationMode="automatic" | "manual"`, `keepMounted`, `fullWidth`, `listClassName` y `contentClassName`. Con `keepMounted`, los paneles inactivos conservan estado y quedan ocultos. Personalizá su nombre con `aria-label`.

### Dialog, Modal y Tooltip

Dialog y Modal usan estado controlado `open`/`onOpenChange`. Admiten `trigger`, `title`, `description`, `actions`, `size`, `initialFocusId`, `closeOnEscape`, `closeOnOutsideClick` y `showCloseButton`. Modal siempre bloquea el fondo; Dialog admite `modal={false}`. Los triggers deben aceptar props y ref; Button ya lo hace. Mantené el componente montado y cambiá `open` para permitir la salida animada.

Tooltip recibe un único elemento React como `children`, más `content`. Admite props de posicionamiento de Radix, `delayDuration`, `withArrow` y `alwaysDark`. El elemento usado como trigger debe aceptar props y ref.

Los menús, Dialog/Modal y Tooltip se transforman desde el tamaño, posición y color de su disparador y vuelven hacia él al cerrar. El texto conserva sus proporciones y el contenido se revela durante la transformación. DropdownButton y Tooltip mantienen el contorno vacío del disparador en su lugar hasta terminar el cierre. La superficie recibe eventos del puntero al completar la apertura, evitando selecciones accidentales al soltar un clic breve. Radix conserva el posicionamiento, teclado y foco; durante la salida, el contenido queda fuera de la interacción. El movimiento reducido muestra el estado final directamente. Toast mantiene su animación independiente.

Para un Dialog o Modal abierto por un control externo, pasá `originRef` con la ref de ese control. Si no hay disparador ni origen, la ventana usa una entrada breve desde su posición final. Conservá el componente montado al cambiar `open` para permitir la salida.

### Toast

ToastProvider ofrece `position`, `maxVisibleToasts` y `viewportLabel`. `useToast()` devuelve `toast`, `success`, `error`, `warning`, `loading`, `updateToast` y `removeToast`.

```tsx
const id = loading('Subiendo archivo…');
updateToast(id, { type: 'success', title: 'Archivo subido' });
```

`ToastOptions` recibe `title`, `description`, `type` (`default`, `success`, `warning`, `error`, `loading`), `duration` en milisegundos, `dismissible`, `closeButtonLabel` y `action: { label, onClick, altText? }`. La duración normal es 4000 ms; `Infinity` desactiva el cierre. Al resolver un aviso loading sin indicar otra duración, se restauran 4000 ms.

Radix pausa el tiempo restante al pasar el puntero, enfocar el aviso o salir de la ventana. F8 lleva el foco a las notificaciones. La pila compacta muestra los tres avisos más recientes por defecto (`maxVisibleToasts` ajusta ese límite); cada aviso nuevo aparece al frente y desplaza el más antiguo fuera de la vista. Los avisos ocultos permanecen pendientes sin montarse ni consumir duración.

Pasar el cursor sobre una pila de varios avisos expande el historial del más reciente al más antiguo, sin mover el foco. Al retirar el cursor se contrae, salvo que el foco esté dentro de las notificaciones. Con teclado, Enter o Espacio sobre el viewport también expanden la pila. «Contraer», Escape, salir con el foco o pulsar afuera la contraen. «Eliminar todas» vacía la lista y ambos controles salen junto con los avisos. Escape en la vista compacta y swipe permiten descartar avisos.

El historial es transparente y adapta su altura al contenido, con un límite equivalente a cuatro avisos estándar y al espacio disponible en la pantalla. Los mensajes largos conservan su contenido. El scroll no muestra barra y un gradiente inferior indica que queda contenido por debajo. Las tarjetas se desplazan y cambian de escala con un resorte amortiguado; la opacidad usa un fundido breve. Al borrar avisos, la tarjeta saliente conserva su posición mientras las restantes se acomodan; el viewport mantiene su altura hasta terminar la salida del último aviso.

Toast también puede usarse solo, con `id` y `onClose(id)` obligatorios: crea un viewport local si no hay ToastProvider. Para coordinar varios avisos, usá el provider. Las acciones cierran el aviso después de ejecutarse; `altText` explica una alternativa accesible cuando corresponda.

### Avatar y Spinner

Avatar usa Radix Image/Fallback. Acepta `src` opcional, `name`, `alt` y `fallback`; muestra iniciales mientras carga o si la imagen falla. Una acción recibe `actionIcon`, `actionLabel` y `onActionClick`.

Spinner admite `size`, `color` y `aria-label`; el nombre predeterminado es "Cargando". El movimiento reducido elimina la rotación.

### Layout y Sidebar

Stack administra dirección, gap, alineación, distribución y wrap; `mobileDirection` permite variar la dirección desde `sm`. Surface admite etiqueta semántica, material, padding, borde y elevación. Sidebar conserva selección y contracción controladas, opciones con `href`, iconos, badges, encabezado y pie. La navegación se puede scrollear sin barras visibles; un gradiente inferior aparece mientras quedan opciones por debajo y desaparece al llegar al final. `onItemSelect` recibe el item y el evento para integrar routers.

## Arquitectura y mantenimiento

- [Diagrama interactivo](docs/arquitectura-componentes.html): aplicación, componentes, providers, portales y servicios externos.
- [Contrato de integración](docs/arquitectura.md): responsabilidades y flujo de datos.
- [Backlog](ComponentList.md): componentes existentes y futuras incorporaciones.
- [Propuestas originales](docs/roadmap-api.md): planificación histórica; no es la API publicada.
- [Evaluación inicial](docs/evaluacion-2026-10-06.md): diagnóstico anterior a estas correcciones.
- [Correcciones y verificación](docs/correcciones-2026-10-06.md): resultado de la migración y cambios para consumidores.

El diagrama está escrito en español; los controles fijos del visor Archify están en inglés. No hay llamadas HTTP, persistencia ni permisos de negocio dentro de los componentes.

La licencia de distribución todavía debe ser definida por quienes mantienen el proyecto antes de publicarlo.
